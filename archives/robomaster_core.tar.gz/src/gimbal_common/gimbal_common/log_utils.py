"""统一日志封装：前缀 ``[<node>.<name>]`` + 基于单调时钟的节流。

* ``get_logger(node, name)`` 返回 rclpy logger（名为 ``<node_name>.<name>``，
  rclpy 输出已自带 ``[node_name]`` 前缀）。
* ``throttled(...)`` 用 :func:`gimbal_common.time_utils.now` 做节流，
  **不用** 墙上时钟，避免系统时钟跳变导致节流失效。
* 状态迁移 / 首次冻结 / reinit / 丢失重捕获等必打日志用 WARN 或 INFO。

rclpy 在本模块内**惰性导入**，因此纯 Python 环境下可以 import 本模块。
"""

from __future__ import annotations

from typing import Any, Dict, Optional, Union

from . import time_utils

__all__ = ['get_logger', 'throttled', 'reset_throttle', 'LEVELS']

LEVELS = ('debug', 'info', 'warn', 'error', 'fatal')

_LAST_EMIT: Dict[str, float] = {}


def _emit(logger: Any, level: Union[str, int], msg: str) -> None:
    """按等级输出一条日志（兼容 rclpy logger 与标准 logging）。"""
    lv = str(level).lower() if isinstance(level, str) else level
    if lv in ('warn', 'warning', 30):
        fn = getattr(logger, 'warning', None) or getattr(logger, 'warn')
        fn(msg)
    elif lv in ('error', 40):
        logger.error(msg)
    elif lv in ('fatal', 'critical', 50):
        logger.fatal(msg)
    elif lv in ('debug', 10):
        logger.debug(msg)
    else:
        logger.info(msg)


def get_logger(node: Any = None, name: str = 'gimbal') -> Any:
    """取得带节点前缀的 logger。

    Args:
        node: rclpy 节点（可为 None，此时只用 name）。
        name: 子节点/模块名，用于日志定位。

    Returns:
        rclpy（或标准 logging）logger。
    """
    try:
        import rclpy.logging as _rclpy_logging
    except ImportError:
        import logging as _logging
        base = node.get_name() if node is not None and hasattr(node, 'get_name') else 'gimbal'
        return _logging.getLogger(f'{base}.{name}')
    base = node.get_name() if node is not None and hasattr(node, 'get_name') else 'gimbal'
    return _rclpy_logging.get_logger(f'{base}.{name}')


def throttled(logger: Any, level: Union[str, int], msg: str, key: str,
              period_s: float = 1.0) -> bool:
    """节流日志：同一 ``key`` 在 ``period_s`` 内只输出一次。

    Args:
        logger: 日志对象。
        level: ``'debug'/'info'/'warn'/'error'/'fatal'``。
        msg: 日志内容。
        key: 节流键（全局唯一，建议带上节点/模块名）。
        period_s: 节流周期（秒）。

    Returns:
        bool: 本次是否真的输出。
    """
    t = time_utils.now()
    last = _LAST_EMIT.get(key, None)
    if last is not None and (t - last) < float(period_s):
        return False
    _LAST_EMIT[key] = t
    _emit(logger, level, msg)
    return True


def reset_throttle(key: Optional[str] = None) -> None:
    """清空节流记录；``key=None`` 时清空全部。"""
    if key is None:
        _LAST_EMIT.clear()
    else:
        _LAST_EMIT.pop(key, None)
